package chenjunfu2.decoratedpotearly.client.mixin;

import chenjunfu2.decoratedpotearly.api.DecoratedPotBlockEntityHelper;
import chenjunfu2.decoratedpotearly.data.DecoratedPotWobbleType;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_7833;
import net.minecraft.class_8172;
import net.minecraft.class_8188;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_8188.class)
public class DecoratedPotBlockEntityRendererMixin
{
	@Inject
	(
		method = "render(Lnet/minecraft/block/entity/DecoratedPotBlockEntity;FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;II)V",
		at = @At
		(
			value = "INVOKE",
			target = "Lnet/minecraft/client/util/SpriteIdentifier;getVertexConsumer(Lnet/minecraft/client/render/VertexConsumerProvider;Ljava/util/function/Function;)Lnet/minecraft/client/render/VertexConsumer;",
			shift = At.Shift.BEFORE
		)
	)
	void renderInject(class_8172 decoratedPotBlockEntity, float f, class_4587 matrixStack, class_4597 vertexConsumerProvider, int i, int j, CallbackInfo ci)
	{
		DecoratedPotWobbleType wobbleType = ((DecoratedPotBlockEntityHelper)decoratedPotBlockEntity).decoratedpotearly$getLastWobbleType();
		if (wobbleType != null && decoratedPotBlockEntity.method_10997() != null)
		{
			float g = ((float)(decoratedPotBlockEntity.method_10997().method_8510() - ((DecoratedPotBlockEntityHelper)decoratedPotBlockEntity).decoratedpotearly$getLastWobbleTime()) + f) / wobbleType.lengthInTicks;
			if (g >= 0.0F && g <= 1.0F)
			{
				if (wobbleType == DecoratedPotWobbleType.POSITIVE)
				{
					float h = 0.015625F;
					float k = g * (float) (Math.PI * 2);
					float l = -1.5F * (class_3532.method_15362(k) + 0.5F) * class_3532.method_15374(k / 2.0F);
					matrixStack.method_49278(class_7833.field_40714.rotation(l * 0.015625F), 0.5F, 0.0F, 0.5F);
					float m = class_3532.method_15374(k);
					matrixStack.method_49278(class_7833.field_40718.rotation(m * 0.015625F), 0.5F, 0.0F, 0.5F);
				}
				else
				{
					float h = class_3532.method_15374(-g * 3.0F * (float) Math.PI) * 0.125F;
					float k = 1.0F - g;
					matrixStack.method_49278(class_7833.field_40716.rotation(h * k), 0.5F, 0.0F, 0.5F);
				}
			}
		}
	}

}
