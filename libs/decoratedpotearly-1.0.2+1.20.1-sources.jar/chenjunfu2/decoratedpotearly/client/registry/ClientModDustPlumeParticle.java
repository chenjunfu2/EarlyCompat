package chenjunfu2.decoratedpotearly.client.registry;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2400;
import net.minecraft.class_4002;
import net.minecraft.class_4794;
import net.minecraft.class_5253;
import net.minecraft.class_638;
import net.minecraft.class_703;
import net.minecraft.class_707;

@Environment(EnvType.CLIENT)
public class ClientModDustPlumeParticle extends class_4794
{
	private static final int COLOR = 12235202;
	
	protected ClientModDustPlumeParticle(
		class_638 world, double x, double y, double z, double velocityX, double velocityY, double velocityZ, float scaleMultiplier, class_4002 spriteProvider
	)
	{
		super(world, x, y, z, 0.7F, 0.6F, 0.7F, velocityX, velocityY + 0.15F, velocityZ, scaleMultiplier, spriteProvider, 0.5F, 7, 0.5F, false);
		float f = (float)Math.random() * 0.2F;
		this.field_3861 = class_5253.class_5254.method_27765(12235202) / 255.0F - f;
		this.field_3842 = class_5253.class_5254.method_27766(12235202) / 255.0F - f;
		this.field_3859 = class_5253.class_5254.method_27767(12235202) / 255.0F - f;
	}
	
	@Override
	public void method_3070()
	{
		this.field_3844 = 0.88F * this.field_3844;
		this.field_28786 = 0.92F * this.field_28786;
		super.method_3070();
	}
	
	@Environment(EnvType.CLIENT)
	public static class Factory implements class_707<class_2400>
	{
		private final class_4002 spriteProvider;
	
		public Factory(class_4002 spriteProvider)
		{
			this.spriteProvider = spriteProvider;
		}
	
		public class_703 createParticle(class_2400 defaultParticleType, class_638 clientWorld, double d, double e, double f, double g, double h, double i)
		{
			return new ClientModDustPlumeParticle(clientWorld, d, e, f, g, h, i, 1.0F, this.spriteProvider);
		}
	}
}
