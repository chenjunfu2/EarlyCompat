package chenjunfu2.decoratedpotearly.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2487;
import net.minecraft.class_2591;
import net.minecraft.class_8164;
import net.minecraft.class_8172;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_8164.class)
public abstract class CraftingDecoratedPotRecipeMixin
{
	@Inject
	(
		method = "getPotStackWith",
		cancellable = true,
		at = @At
		(
			value = "INVOKE",
			shift = At.Shift.BEFORE,
			target = "Lnet/minecraft/block/entity/DecoratedPotBlockEntity$Sherds;toNbt(Lnet/minecraft/nbt/NbtCompound;)Lnet/minecraft/nbt/NbtCompound;"
		)
	)
	private static void getPotStackWithInject(class_8172.class_8526 sherds, CallbackInfoReturnable<class_1799> cir, @Local class_1799 itemStack)
	{
		if(sherds.comp_1487() == class_1802.field_8621 &&
		   sherds.comp_1488() == class_1802.field_8621 &&
		   sherds.comp_1489() == class_1802.field_8621 &&
		   sherds.comp_1490() == class_1802.field_8621)
		{
			cir.setReturnValue(itemStack);
			cir.cancel();
		}
	}
	
	@WrapOperation
	(
		method = "getPotStackWith",
		at = @At(value = "INVOKE", target = "Lnet/minecraft/item/BlockItem;setBlockEntityNbt(Lnet/minecraft/item/ItemStack;Lnet/minecraft/block/entity/BlockEntityType;Lnet/minecraft/nbt/NbtCompound;)V")
	)
	private static void getPotStackWithWrapOperation(class_1799 stack, class_2591<?> blockEntityType, class_2487 tag, Operation<Void> original)
	{
		if (tag.method_33133())
		{
			stack.method_7983("BlockEntityTag");
		}
		else
		{
			stack.method_7959("BlockEntityTag", tag);
		}
	}
}
