package chenjunfu2.decoratedpotearly.mixin;

import net.minecraft.class_2746;
import net.minecraft.class_8168;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_8168.class)
public interface DecoratedPotBlockAccessor
{
	@Accessor("CRACKED")
	static class_2746 getCRACKED()
	{
		throw new AssertionError();//Mixin自动替换
	}
}
