package chenjunfu2.decoratedpotearly.mixin;


import chenjunfu2.decoratedpotearly.api.DecoratedPotBlockEntityHelper;
import chenjunfu2.decoratedpotearly.data.DecoratedPotWobbleType;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_8172;
import org.spongepowered.asm.mixin.Intrinsic;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_8172.class)
public abstract class DecoratedPotBlockEntityMixin extends class_2586 implements DecoratedPotBlockEntityHelper, class_1263
{
	// super
	public DecoratedPotBlockEntityMixin(class_2591<?> type, class_2338 pos, class_2680 state)
	{
		super(type, pos, state);
	}
	
	// Data
	@Unique
	public long decoratedpotearly$lastWobbleTime;
	
	@Unique
	public DecoratedPotWobbleType decoratedpotearly$lastWobbleType;
	
	@Unique
	private class_1799 decoratedpotearly$stack = class_1799.field_8037;
	
	// Override BlockEntity
	@Override
	public boolean method_11004(int type, int data) {
		if (this.field_11863 != null && type == 1 && data >= 0 && data < DecoratedPotWobbleType.values().length)
		{
			this.decoratedpotearly$lastWobbleTime = this.field_11863.method_8510();
			this.decoratedpotearly$lastWobbleType = DecoratedPotWobbleType.values()[data];
			return true;
		}
		else
		{
			return super.method_11004(type, data);
		}
	}
	
	// Mixin
	@Inject(method = "writeNbt", at = @At(value = "RETURN"))
	void writeNbtInject(class_2487 nbt, CallbackInfo ci)
	{
		if (!this.decoratedpotearly$stack.method_7960())
		{
			class_2487 itemNBT = new class_2487();
			this.decoratedpotearly$stack.method_7953(itemNBT);
			nbt.method_10566("item", itemNBT);
		}
	}
	
	@Inject(method = "readNbt", at = @At(value = "RETURN"))
	void readNbtInject(class_2487 nbt, CallbackInfo ci)
	{
		if (nbt.method_10573("item", class_2520.field_33260))
		{
			class_2487 itemNBT = nbt.method_10562("item");
			this.decoratedpotearly$stack = class_1799.method_7915(itemNBT);
		}
		else
		{
			this.decoratedpotearly$stack = class_1799.field_8037;
		}
	}
	
	// DecoratedPotBlockEntityHelper
	@Unique
	@Override
	public class_1799 decoratedpotearly$getStack()
	{
		return this.decoratedpotearly$stack;
	}

	@Unique
	@Override
	public void decoratedpotearly$setStack(class_1799 decoratedPotItemStack)
	{
		this.decoratedpotearly$stack = decoratedPotItemStack;
	}

	@Unique
	@Override
	public boolean decoratedpotearly$isEmpty()
	{
		return this.decoratedpotearly$stack.method_7960();
	}
	
	@Unique
	@Override
	public void decoratedpotearly$wobble(DecoratedPotWobbleType wobbleType)
	{
		if (this.field_11863 != null && !this.field_11863.method_8608())
		{
			this.field_11863.method_8427(this.method_11016(), this.method_11010().method_26204(), 1, wobbleType.ordinal());
		}
	}
	
	@Unique
	@Override
	public long decoratedpotearly$getLastWobbleTime()
	{
		return decoratedpotearly$lastWobbleTime;
	}
	
	@Unique
	@Override
	public void decoratedpotearly$setLastWobbleTime(long wobbleTime)
	{
		this.decoratedpotearly$lastWobbleTime = wobbleTime;
	}
	
	@Unique
	@Override
	public DecoratedPotWobbleType decoratedpotearly$getLastWobbleType()
	{
		return decoratedpotearly$lastWobbleType;
	}
	
	@Unique
	@Override
	public void decoratedpotearly$setLastWobbleType(DecoratedPotWobbleType wobbleType)
	{
		this.decoratedpotearly$lastWobbleType = wobbleType;
	}
	
	//Inventory
	@Override
	public int method_5439()
	{
		return 1;//只有一个
	}
	
	@Override
	public boolean method_5442()
	{
		return this.decoratedpotearly$stack.method_7960();
	}
	
	@Override
	public class_1799 method_5438(int slot)
	{
		if(slot != 0)
		{
			return class_1799.field_8037;
		}
		
		
		return this.decoratedpotearly$stack;
	}
	
	@Override
	public class_1799 method_5434(int slot, int amount)
	{
		if(slot != 0 || amount <= 0 || this.decoratedpotearly$stack.method_7960())
		{
			return class_1799.field_8037;
		}

		return this.decoratedpotearly$stack.method_7971(amount);
	}

	@Override
	public class_1799 method_5441(int slot)
	{
		if(slot != 0)
		{
			return class_1799.field_8037;
		}
		
		return this.decoratedpotearly$stack = class_1799.field_8037;
	}
	
	@Override
	public void method_5447(int slot, class_1799 decoratedPotItemStack)
	{
		if(slot != 0)
		{
			return;
		}
		
		this.decoratedpotearly$stack = decoratedPotItemStack;
	}
	
	@Override
	@Intrinsic
	public void method_5431()
	{
		super.method_5431();
	}
	
	@Override
	public boolean method_5443(class_1657 player)
	{
		return class_1263.method_49105(((class_8172)(Object)this),player);
	}
	
	@Override
	public void method_5448()
	{
		this.decoratedpotearly$stack = class_1799.field_8037;
	}
}
