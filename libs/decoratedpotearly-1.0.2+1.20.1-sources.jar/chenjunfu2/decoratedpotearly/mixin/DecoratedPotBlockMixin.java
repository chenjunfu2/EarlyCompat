package chenjunfu2.decoratedpotearly.mixin;

import chenjunfu2.decoratedpotearly.api.DecoratedPotBlockEntityHelper;
import chenjunfu2.decoratedpotearly.registry.ModParticles;
import chenjunfu2.decoratedpotearly.registry.ModSoundEvents;
import chenjunfu2.decoratedpotearly.data.DecoratedPotWobbleType;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;

import java.util.List;
import net.minecraft.class_1263;
import net.minecraft.class_1264;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2520;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3419;
import net.minecraft.class_3468;
import net.minecraft.class_3965;
import net.minecraft.class_5712;
import net.minecraft.class_8168;
import net.minecraft.class_8172;

@Mixin(class_8168.class)
public abstract class DecoratedPotBlockMixin extends class_2237//继承基类用于super方法
{
	protected DecoratedPotBlockMixin(class_2251 settings)
	{
		super(settings);
	}
	
	//覆盖DecoratedPotBlock的基类onUse方法
	@Override
	public class_1269 method_9534(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit)
	{
		//DecoratedPotEarly.LOGGER.info("onUse");
		if (world.method_8321(pos) instanceof class_8172 decoratedPotBlockEntity)
		{
			if (world.field_9236)
			{
				return class_1269.field_5812;
			}
			else
			{
				//这里是ItemUse路径
				class_1799 playerStack = player.method_6047();//只看主手，副手无反应
				
				class_1799 itemStack = ((DecoratedPotBlockEntityHelper)decoratedPotBlockEntity).decoratedpotearly$getStack();
				if (!playerStack.method_7960() && (itemStack.method_7960() || class_1799.method_31577(itemStack, playerStack) && itemStack.method_7947() < itemStack.method_7914()))
				{
					//动画
					((DecoratedPotBlockEntityHelper)decoratedPotBlockEntity).decoratedpotearly$wobble(DecoratedPotWobbleType.POSITIVE);
					player.method_7259(class_3468.field_15372.method_14956(playerStack.method_7909()));
					
					//物品交互
					float f;
					if (((DecoratedPotBlockEntityHelper)decoratedPotBlockEntity).decoratedpotearly$isEmpty())
					{
						class_1799 itemStack2 = !player.method_7337() ? playerStack.method_7971(1) : playerStack.method_46651(1);
						((DecoratedPotBlockEntityHelper)decoratedPotBlockEntity).decoratedpotearly$setStack(itemStack2);
						f = (float)itemStack2.method_7947() / itemStack2.method_7914();
					}
					else
					{
						if (!player.method_7337())
						{
							playerStack.method_7934(1);
						}
						itemStack.method_7933(1);
						f = (float)itemStack.method_7947() / itemStack.method_7914();
					}
					
					//声音
					world.method_8396(null, pos, ModSoundEvents.BLOCK_DECORATED_POT_INSERT, class_3419.field_15245, 1.0F, 0.7F + 0.5F * f);
					
					//粒子效果
					if (world instanceof class_3218 serverWorld)
					{
						serverWorld.method_14199(ModParticles.DUST_PLUME, pos.method_10263() + 0.5, pos.method_10264() + 1.2, pos.method_10260() + 0.5, 7, 0.0, 0.0, 0.0, 0.0);
					}
					
					//更新
					decoratedPotBlockEntity.method_5431();
					world.method_33596(player, class_5712.field_28733, pos);
					return class_1269.field_5812;
				}
				else
				{
					//这里走正常方块use路径
					world.method_8396(null, pos, ModSoundEvents.BLOCK_DECORATED_POT_INSERT_FAIL, class_3419.field_15245, 1.0F, 1.0F);
					((DecoratedPotBlockEntityHelper)decoratedPotBlockEntity).decoratedpotearly$wobble(DecoratedPotWobbleType.NEGATIVE);
					world.method_33596(player, class_5712.field_28733, pos);
					
					return class_1269.field_5812;//并总是返回成功
				}
			}
		}
		else
		{
			return class_1269.field_5811;
		}
	}
	
	//覆盖基类
	//内部物品掉落
	@Override
	public void method_9536(class_2680 state, class_1937 world, class_2338 pos, class_2680 newState, boolean moved)
	{
		if (!state.method_27852(newState.method_26204()))
		{
			class_2586 blockEntity = world.method_8321(pos);
			if (blockEntity instanceof class_1263)
			{
				class_1264.method_5451(world, pos, (class_1263)blockEntity);
				world.method_8455(pos, (class_8168)(Object)this);
			}
			
			super.method_9536(state, world, pos, newState, moved);
		}
	}
	
	//比较器方法
	@Override
	public boolean method_9498(class_2680 state) {
		return true;
	}
	
	@Override
	public int method_9572(class_2680 state, class_1937 world, class_2338 pos)
	{
		return class_1703.method_7608(world.method_8321(pos));
	}
	
	@Unique
	private static class_1799 decoratedpotearly$getStackWith(class_8172.class_8526 sherds)
	{
		class_1799 itemStack = class_1802.field_42699.method_7854();
		
		if(sherds.comp_1487() == class_1802.field_8621 &&
		   sherds.comp_1488() == class_1802.field_8621 &&
		   sherds.comp_1489() == class_1802.field_8621 &&
		   sherds.comp_1490() == class_1802.field_8621)
		{
			return itemStack;
		}
		
		//返回自定义nbt
		class_2487 nbtCompound = sherds.method_51513(new class_2487());
		itemStack.method_7959("BlockEntityTag", nbtCompound);
		return itemStack;
	}
	
	@Override
	public class_1799 method_9574(class_1922 world, class_2338 pos, class_2680 state)
	{
		if (world.method_8321(pos) instanceof class_8172 decoratedPotBlockEntity)
		{
			class_8172.class_8526 sherds = decoratedPotBlockEntity.method_51511();
			return decoratedpotearly$getStackWith(sherds);
		}
		else
		{
			return super.method_9574(world, pos, state);
		}
	}
	
	//NBT修复
	@ModifyReturnValue(
		method = "getDroppedStacks",
		at = @At(
			value = "RETURN"
		)
	)
	private List<class_1799> modifyDroppedStacks(List<class_1799> original)//掉落依据战利品表，所以只能等生成后再删除nbt
	{
		//已在合成配方中mixin去掉id，并且正常掉落不会附加id（和潜影盒不同），所以无需处理id
		
		//不为空并且仅含1物品才处理
		if (original == null || original.size() != 1)
		{
			return original;
		}

		//拿到物品
		var item = original.get(0);
		if (item == null)
		{
			return original;
		}

		//获取掉落物的itemTag
		var itemTag = item.method_7969();

		//必须存在且类型正确
		if(itemTag == null || !itemTag.method_10573("BlockEntityTag", class_2520.field_33260))
		{
			return original;
		}

		//获取方块实体tag
		var tagBETag = itemTag.method_10562("BlockEntityTag");

		do
		{
			//然后检查是否全部由brick组成，是的话直接删除
			if(!tagBETag.method_10573("sherds",class_2520.field_33259))
			{
				break;
			}

			var sherds = (class_2499)tagBETag.method_10580("sherds");
			if(sherds.size() != 4 || sherds.method_10601() != class_2520.field_33258)
			{
				break;
			}

			//确定4个都是brick
			boolean bIsAllBrick = true;
			for(var it : sherds)
			{
				if(!((class_2519)it).method_10714().equals("minecraft:brick"))
				{
					bIsAllBrick = false;
					break;
				}
			}

			//是就删除
			if(bIsAllBrick)
			{
				tagBETag.method_10551("sherds");
			}

		}while(false);

		//如果移除后啥tagBETag都没了，那么把BlockEntityTag也删除，不要留下空的BlockEntityTag
		if(tagBETag.method_33133())
		{
			itemTag.method_10551("BlockEntityTag");
		}

		//如果移除BlockEntityTag之后itemTag里啥都没了，那么把itemTag设为null，不要留下空（但是非null）的itemTag
		if(itemTag.method_33133())
		{
			item.method_7980(null);//需要设置item内部的itemTag，而不是单纯的赋值itemTag为null
		}

		return original;
	}

}