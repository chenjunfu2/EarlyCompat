package chenjunfu2.decoratedpotearly.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_1802.class)
public abstract class ItemsMixin
{
	@WrapOperation
	(
		method = "<clinit>",
		at = @At
		(
			value = "INVOKE",
			target = "Lnet/minecraft/item/Item$Settings;maxCount(I)Lnet/minecraft/item/Item$Settings;",
			ordinal = 0//第0个就是：public static final Item DECORATED_POT = register(new BlockItem(Blocks.DECORATED_POT, new Item.Settings().maxCount(1)));
		)
	)
	private static class_1792.class_1793 modifyDecoratedPotStackSize(class_1792.class_1793 instance, int maxCount, Operation<class_1792.class_1793> original)
	{
		//取消调用，回到64
		//original.call(instance, maxCount);
		return instance;
	}
}
