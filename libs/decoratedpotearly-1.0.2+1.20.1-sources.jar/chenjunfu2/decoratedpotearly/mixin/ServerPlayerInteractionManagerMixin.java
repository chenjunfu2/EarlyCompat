package chenjunfu2.decoratedpotearly.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3225;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(class_3225.class)
public class ServerPlayerInteractionManagerMixin
{
	@Shadow
	protected class_3218 world;//偷出来
	
	@ModifyVariable
	(
		method = "tryBreakBlock",
		at = @At
		(
			value = "INVOKE",
			target = "Lnet/minecraft/block/Block;onBreak(Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/BlockState;Lnet/minecraft/entity/player/PlayerEntity;)V",
			shift = At.Shift.AFTER
		),
		ordinal = 0
	)
	private class_2680 updateBlockState(class_2680 original, @Local class_2338 pos)
	{
		return world.method_8320(pos);
	}
}
