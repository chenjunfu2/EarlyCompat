package chenjunfu2.decoratedpotearly.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.class_212;
import net.minecraft.class_2248;
import net.minecraft.class_2430;
import net.minecraft.class_4559;
import net.minecraft.class_5341;
import net.minecraft.class_79;
import net.minecraft.class_85;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_2430.class)
public abstract class VanillaBlockLootTableGeneratorMixin
{
	@WrapOperation
	(
		method = "decoratedPotDrops",
		at = @At
		(
			value = "INVOKE",
			target = "Lnet/minecraft/loot/entry/LeafEntry$Builder;conditionally(Lnet/minecraft/loot/condition/LootCondition$Builder;)Lnet/minecraft/loot/entry/LootPoolEntry$Builder;",
			ordinal = 0
		)
	)
	class_79.class_80 decoratedPotDropsWrapOperation0(class_85.class_86 instance, class_5341.class_210 builder, Operation<class_79.class_80> original, @Local class_2248 block)
	{
		//丢弃原先的builder，替换为自定义builder
		return original.call(instance,
			class_212
			.method_900(block)
			.method_22584
			(
				class_4559.class_4560
				.method_22523()
				.method_22527(DecoratedPotBlockAccessor.getCRACKED(), true)
			)
		);
	}
	
	@WrapOperation
	(
		method = "decoratedPotDrops",
		at = @At
		(
			value = "INVOKE",
			target = "Lnet/minecraft/loot/entry/LeafEntry$Builder;conditionally(Lnet/minecraft/loot/condition/LootCondition$Builder;)Lnet/minecraft/loot/entry/LootPoolEntry$Builder;",
			ordinal = 1
		)
	)
	class_79.class_80 decoratedPotDropsWrapOperation1(class_85.class_86 instance, class_5341.class_210 builder, Operation<class_79.class_80> original)
	{
		return instance;//跳过第二个调用
	}

}
