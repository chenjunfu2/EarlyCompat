package chenjunfu2.decoratedpotearly.registry;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_2246;
import net.minecraft.class_7706;

public class ModBlocks
{
	public static void registerBlocks()
	{
		ItemGroupEvents.modifyEntriesEvent(class_7706.field_40198).register(content -> content.addAfter(class_2246.field_10223, class_2246.field_42752));
	}
}
