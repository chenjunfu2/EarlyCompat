package chenjunfu2.decoratedpotearly.registry;

import net.fabricmc.fabric.api.particle.v1.FabricParticleTypes;
import net.minecraft.class_2378;
import net.minecraft.class_2400;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class ModParticles
{
	public static final class_2400 DUST_PLUME =
		class_2378.method_10230
		(
			class_7923.field_41180,
			new class_2960("dust_plume"),
			FabricParticleTypes.simple(false)
		);
	
	public static void registerParticles() {}
}
