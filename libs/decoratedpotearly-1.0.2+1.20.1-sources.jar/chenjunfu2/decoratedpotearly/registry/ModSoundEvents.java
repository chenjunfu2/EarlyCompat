package chenjunfu2.decoratedpotearly.registry;

import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_7923;

public class ModSoundEvents
{
	//只需要这两个，剩下的原版已经有了
	public static final class_3414 BLOCK_DECORATED_POT_INSERT = register("block.decorated_pot.insert");
	public static final class_3414 BLOCK_DECORATED_POT_INSERT_FAIL = register("block.decorated_pot.insert_fail");
	
	private static class_3414 register(String name)
	{
		final class_2960 id = new class_2960(name);
		return class_2378.method_10230(class_7923.field_41172, id, class_3414.method_47908(id));
	}
	
	public static void registerSounds() {}
}
